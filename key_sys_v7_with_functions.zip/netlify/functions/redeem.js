export async function handler(event, context) {
  const { key } = event.queryStringParameters;

  // ✅ Example validation (replace with real logic)
  if (key && key.startsWith("KEY-")) {
    return {
      statusCode: 200,
      body: JSON.stringify({ valid: true, message: "Key accepted!" })
    };
  }

  return {
    statusCode: 400,
    body: JSON.stringify({ valid: false, message: "INVALID KEY" })
  };
}
