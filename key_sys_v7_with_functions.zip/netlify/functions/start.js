export async function handler(event, context) {
  const { source, name } = event.queryStringParameters;

  return {
    statusCode: 200,
    body: JSON.stringify({
      sessionId: Math.random().toString(36).substring(2, 10),
      source,
      name
    })
  };
}
